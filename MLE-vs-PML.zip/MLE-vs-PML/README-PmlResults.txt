PML results are under ./01_independentNonlinearModels/
'results/estByNeighborAverage' directory.

The parameters estimated using the result values optimized
in R.
