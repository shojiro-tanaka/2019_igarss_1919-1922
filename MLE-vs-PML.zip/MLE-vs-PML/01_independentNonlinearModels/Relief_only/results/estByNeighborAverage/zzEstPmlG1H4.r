#��ƃf�B���N�g�������̃t�@�C���Ɠ����ꏊ�ɕύX
#setwd(dirname(sys.frame(1)$ofile))

#�S�ϐ��̏������C���Z�b�g
rm(list=ls(all=TRUE))

dir.create("./logPml")

sink('./logPml/estPmlG1H4.txt')

tmp <- list.files("../")
str<-paste("..", tmp[6], sep = "/")

resultG1H4 <- readRDS(str)

library("Matrix")
library(MASS)

# N:�l�����x
# R:�W����
# H1:�אڍs��

# �����ϐ��̓ǂݍ���
X = read.csv("./../../../../00_dataToRead/X.csv", header=FALSE)
#colnames(X)[4:6] = c("F", "N", "R")

F = data.matrix(X[, 4])
N = data.matrix(X[, 5])
R = data.matrix(X[, 6])
altmean = data.matrix(X[, 7])
logitF <- log ( F/(1.0 - F) )
logN <- log( N+1.0 )
adjustTerm <- 2*sum(log(F*(1.0-F)))
rm(X, F, N)

dataSize = nrow(logitF)

print(dataSize)
print(resultG1H4)

# �אڍs��̓ǂݍ���
H1_mat = read.csv("./../../../../00_dataToRead/H1_mat.csv", header=FALSE)
H1 = data.matrix(H1_mat)
sum(rowSums(H1)-colSums(H1))
rm(H1_mat)
H2_mat = read.csv("./../../../../00_dataToRead/H2_mat.csv", header=FALSE)
H2 = data.matrix(H2_mat)
sum(rowSums(H2)-colSums(H2))
rm(H2_mat)

Hc = H1 + H2

# G1H4 ##############################################################
 B1 = resultG1H4$par[2] * logN
 B2 = resultG1H4$par[3] * ( 1.0 / (1.0+exp(resultG1H4$par[4]-resultG1H4$par[5] * R)) - 1.0 / (1.0 + exp(resultG1H4$par[4])) )
 #
 estLogitF <- resultG1H4$par[1] - B1 + B2 # + resultG1H4$par[6]*altmean

### independent model
### NOTE: mse0 is for the estimate of y = xBeta0 y_hat + error
XX0    = estLogitF;
residual0 <- logitF - estLogitF
XX0sq  = t(XX0) %*% XX0;
xBeta0 = solve(XX0sq) * t(XX0) %*% logitF
mse0   = ( (t(logitF) %*% logitF) - t(xBeta0) * (XX0sq) * xBeta0 )/dataSize
mse0b  = (t(residual0) %*% residual0)/dataSize
aic0   = dataSize*log(mse0) + adjustTerm + 2*( 1 + length(data.matrix(resultG1H4$par)) )
bic0   = dataSize*log(mse0) + adjustTerm + log(dataSize)*( 1 + length(data.matrix(resultG1H4$par)) )
bic0b  = dataSize*log(mse0b) + adjustTerm + log(dataSize)*( 1 + length(data.matrix(resultG1H4$par)) )
cat("beta0  = ", paste(xBeta0),"\n")
cat(" mse0  = ", paste(mse0),",")
cat(" mse0b = ", paste(mse0b),",")
cat(" aic0  = ", paste(aic0),",")
cat(" bic0  = ", paste(bic0),"\n\n")
cat(" bic0b = ", paste(bic0b),"\n\n")

### 1st-order neighbors
rowSummed1  = matrix(rowSums(H1))
xEstLF1sum  = H1 %*% estLogitF
xEstLF1ave  = xEstLF1sum/rowSummed1;
xEstLF1ave[is.nan(xEstLF1ave)] = estLogitF[is.nan(xEstLF1ave)]

XX1    = cbind(estLogitF, xEstLF1ave);
XX1sq  = t(XX1) %*% XX1;
xBeta1 = solve(XX1sq) %*% t(XX1) %*% logitF
mse1   = (t(logitF) %*% logitF - t(xBeta1) %*% XX1sq %*% xBeta1)/dataSize
aic1   = dataSize*log(mse1) + adjustTerm + 2*(1 +length(xBeta1))
bic1   = dataSize*log(mse1) + adjustTerm + log(dataSize)*(1 +length(xBeta1))
cat("beta1  = ", paste(xBeta1),"\n")
cat(" mse1  = ", paste(mse1),",")
cat(" aic1  = ", paste(aic1),",")
cat(" bic1  = ", paste(bic1),"\n\n")

### 2st-order neighbors
rowSummed2  = matrix(rowSums(H2))
xEstLF2sum  = H2 %*% estLogitF
xEstLF2ave  = xEstLF2sum/rowSummed2
xEstLF2ave[is.nan(xEstLF2ave)] = estLogitF[is.nan(xEstLF2ave)]

XX2    = cbind(estLogitF, xEstLF2ave);
XX2sq  = t(XX2) %*% XX2;
xBeta2 = solve(XX2sq) %*% t(XX2) %*% logitF
mse2   = (t(logitF) %*% logitF - t(xBeta2) %*% XX2sq %*% xBeta2)/dataSize
aic2   = dataSize*log(mse2) + adjustTerm + 2*(1 +length(xBeta2))
bic2   = dataSize*log(mse2) + adjustTerm + log(dataSize)*(1 +length(xBeta2))
cat("beta2  = ", paste(xBeta2),"\n")
cat(" mse2  = ", paste(mse2),",")
cat(" aic2  = ", paste(aic2),",")
cat(" bic2  = ", paste(bic2),"\n\n")

### 1st+2nd -order neighbors

XX4    = cbind(estLogitF, xEstLF1ave, xEstLF2ave)
XX4sq  = t(XX4) %*% XX4;
xBeta4 = solve(XX4sq) %*% t(XX4) %*% logitF
mse4   = (t(logitF) %*% logitF - t(xBeta4) %*% XX4sq %*% xBeta4)/dataSize
aic4   = dataSize*log(mse4) + adjustTerm + 2*(1 +length(xBeta4))
bic4   = dataSize*log(mse4) + adjustTerm + log(dataSize)*(1 +length(xBeta4))
cat("beta4  = ", paste(xBeta4),"\n")
cat(" mse4  = ", paste(mse4),",")
cat(" aic4  = ", paste(aic4),",")
cat(" bic4  = ", paste(bic4),"\n\n")

### common surrouding neighbors (eight cells)
rowSummedC  = matrix(rowSums(Hc))
xEstLFcSum  = Hc %*% estLogitF
xEstLFcAve  = xEstLFcSum/rowSummedC
xEstLFcAve[is.nan(xEstLFcAve)] = estLogitF[is.nan(xEstLFcAve)]

XXc    = cbind(estLogitF, xEstLFcAve)
XXcSq = t(XXc) %*% XXc
xBetaC = solve(XXcSq) %*% t(XXc) %*% logitF
mseC   = (t(logitF) %*% logitF - t(xBetaC) %*% XXcSq %*% xBetaC)/dataSize
aicC   = dataSize*log(mseC) + adjustTerm + 2*(1 +length(xBetaC))
bicC   = dataSize*log(mseC) + adjustTerm + log(dataSize)*(1 +length(xBetaC))
cat("betaC  = ", paste(xBetaC),"\n")
cat(" mseC  = ", paste(mseC),",")
cat(" aicC  = ", paste(aicC),",")
cat(" bicC  = ", paste(bicC),"\n")

sink()
closeAllConnections()
