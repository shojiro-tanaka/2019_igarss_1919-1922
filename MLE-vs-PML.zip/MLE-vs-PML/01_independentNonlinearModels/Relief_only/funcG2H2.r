LL <- function(beta){
 count <<- count + 1
 char = paste0('[', count, '] ')
 space = paste0(rep(" ", length=nchar(char)), collapse="")
 cat(paste0(char, 'beta = (', paste(beta,collapse=", "), ')\n'))

 for(k in 2:length(beta)){
  if(beta[k] < 0) beta[k] = 1e-6 * abs(rnorm(1))
 }

 B1 = beta[2] * ( 1 / (1 + exp(beta[3] - beta[4] * logN) )
                 - ( 1 / ( 1 + exp(beta[3]) ) ) )
 B2 <- matrix( 0, nrow = dataSize, ncol =1 )
 for( i in 1:dataSize ){
   if (R[i] <= beta[5]) B2[i] <- 0 
   else B2[i] <- beta[6] * log( R[i] / beta[5] )
 }

 #B2 = beta[6] * log(R / beta[5]) * (sign(R - beta[5]) + 1) / 2
 ## R=0�̂Ƃ��̗�O����
 #B2[is.nan(B2)] = 0

 B = beta[1] - B1 + B2

residual <- data.matrix(logitF - B)
mse = (t(residual) %*% residual) / dataSize

logMse <- log(mse)
final <- as.numeric( dataSize*logMse )
AIC <- final +adjustTerm + 2*(length(beta)+1)
BIC <- final +adjustTerm + log(dataSize)*(length(beta)+1)
cat(paste0(space, 'mse = ', sprintf("%3.5f", mse), '\n', space, 'AIC = ', sprintf("%3.5f", AIC), '\n', space, 'BIC = ', sprintf("%3.5f", BIC), '\n'))
return( BIC )
}
